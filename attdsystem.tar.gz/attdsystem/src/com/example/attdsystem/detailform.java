package com.example.attdsystem;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

public class detailform extends Activity
{	
	EditText mEdit;

	public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_activity);
    } 
	public void showdate (View view) 
	{
		DialogFragment newFragment = new SelectDateFragment();
		newFragment.show(getFragmentManager(), "DatePicker");
	}
	public void populateSetDate(int year, int month, int day) 
	{
		mEdit = (EditText)findViewById(R.id.editText1);
		mEdit.setText(day+"/"+month+"/"+year);
	}
	public class SelectDateFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener 
	{
		@Override
		public Dialog onCreateDialog(Bundle savedInstanceState) 
		{
			final Calendar calendar = Calendar.getInstance();
			int yy = calendar.get(Calendar.YEAR);
			int mm = calendar.get(Calendar.MONTH);
			int dd = calendar.get(Calendar.DAY_OF_MONTH);
			return new DatePickerDialog(getActivity(), this, yy, mm, dd);
		}		 
		public void onDateSet(DatePicker view, int yy, int mm, int dd) 
		{
			populateSetDate(yy, mm+1, dd);
		}  		      
	}		
	public void backmethod(View v)
	{			
		startActivity(new Intent(this, takeview.class));
	}
}
