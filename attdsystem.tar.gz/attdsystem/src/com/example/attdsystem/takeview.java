package com.example.attdsystem;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class takeview extends Activity{
	Context context;
	
	 public void onCreate(Bundle savedInstanceState)
	    {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.takeandview);
	     	        
	    }

	  public void takeattendance (View v)
	  {
		       // start the home activity
              Intent intent = new Intent(takeview.this, detailform.class);
              takeview.this.startActivity(intent);
         }

	  public void viewattendance (View v)
	  {
		       // start the home activity
              Intent intent = new Intent(takeview.this, detailform.class);
              takeview.this.startActivity(intent);
         }
	  
	 
	    
		   public void logout(View v)
		    {
		    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
		        builder.setTitle("Log Out?");
		        builder.setMessage("Are you sure you want to log out?");
		        
		  
		        
		        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener()
		        {

		            @Override
		            public void onClick(DialogInterface dialog, int which) 
		            {
		            	 Intent intent = new Intent(takeview.this, login.class);
		                 takeview.this.startActivity(intent);
		            }
		            
		            
		        });
		        builder.setNegativeButton("Cancel", null);
		        builder.show();
		         
		    }


}
